# LIB_OTTO_SENSORES — soporte de sensores + arreglo del bloque de ultrasonido

Paquete para llevar al **PC con Windows** donde está instalado Blockly. Son
**tres ficheros** y nada más.

| | |
|---|---|
| Base | rama `feat/sensores` sobre `master` (`fd812ab`) |
| Hardware de referencia | Arduino Nano v3 (ATmega328P), HC-SR04 en Trigger 8 / Echo 9 |
| Verificado | **16 cm con regla → 16 cm leídos, dispersión 0 cm** |
| Fecha | 2026-11-13 |

---

## 1. Qué contiene: es un ESPEJO del proyecto

La estructura de carpetas es **idéntica a la del proyecto**, a propósito, para que
el traspaso sea copiar y pegar sin pensar dónde va cada cosa:

```
LIB_OTTO_SENSORES/
├── compilation/arduino/userlibs/libraries/Otto/
│      ├── Otto.h          ← MODIFICADO
│      └── Otto.cpp        ← MODIFICADO
├── www/blocs&generateurs/
│      └── sensors.js      ← MODIFICADO  (el que arregla tus bloques)
├── CAMBIOS.diff           ← el diff completo contra master, para revisar
├── SHA256SUMS.txt         ← con las rutas ya en su sitio
└── README.md
```

### Cómo traspasarlo en Windows

1. **Haz copia de seguridad del proyecto**, o al menos de los tres ficheros que se
   van a sustituir. Son los únicos que cambian.
2. Copia **las dos carpetas de primer nivel** — `compilation` y `www` — sobre la
   raíz del proyecto en Windows, y acepta reemplazar. Como la estructura coincide,
   cada fichero cae en su sitio y **no se toca nada más**: las carpetas solo
   contienen esos tres ficheros.
3. Verifica que llegaron bien. En PowerShell, desde la raíz del proyecto:

```powershell
Get-FileHash -Algorithm SHA256 compilation\arduino\userlibs\libraries\Otto\Otto.h
Get-FileHash -Algorithm SHA256 compilation\arduino\userlibs\libraries\Otto\Otto.cpp
Get-FileHash -Algorithm SHA256 "www\blocs&generateurs\sensors.js"
```

   y compara con `SHA256SUMS.txt`. Ojo: la ruta de `sensors.js` lleva un `&`, así
   que en PowerShell hay que entrecomillarla.

> **Si no quieres copiar las dos carpetas enteras**, los tres ficheros van a:
> `compilation\arduino\userlibs\libraries\Otto\` (los dos primeros) y
> `www\blocs&generateurs\` (el tercero).

> **Los dos arreglos son independientes.** `sensors.js` es el que hace que
> funcionen **tus bloques de ultrasonido**; `Otto.h`/`Otto.cpp` añaden métodos de
> sensor a la librería, que hoy **ningún bloque usa**. Si solo quieres que el
> robot mida, basta con `sensors.js`.

## 2. El problema que esto resuelve

Síntoma reportado: *"usé los dos bloques y no me respetaba las mediciones, pero
no tenía cómo verlo"*.

**Causa medida: el módulo HC-SR04 de esta placa no responde a un pulso de disparo
de 10 µs cuando acaba de alimentarse.** Barrido sobre el mismo obstáculo, con el
módulo en frío:

| ancho del disparo | lecturas válidas |
|---|---|
| **10 µs** ← el que usaba el generador | **0 / 4** |
| 15 µs | 1 / 4 |
| **20 µs** | **4 / 4** |
| 30 µs | 4 / 4 |
| 50 µs | 4 / 4 |

El datasheet de ElecFreaks pide *"at least 10us"*, **sin límite superior**. El
módulo cumple la especificación; el generador leía el mínimo como si fuera el
valor exacto.

**Y una vez despierto, el módulo sí responde a 10 µs**, lo que confunde: al
reprogramar, el ATmega se resetea pero el módulo **no pierde los 5 V** y llega
despierto a la prueba siguiente. En uso real el primer disparo es **siempre en
frío**.

### La cadena completa del fallo

1. Módulo en frío → 10 µs no lo despierta → nunca contesta
2. `pulseIn()` **sin timeout** → espera **un segundo** y devuelve `0`
3. `distance = 0 / 58 = 0 cm`
4. **`si distancia < 15 entonces esquiva` es siempre verdadero** → el robot actúa
   como si tuviera un obstáculo pegado, de forma permanente
5. Más un segundo congelado por lectura, que además destroza el temporizado de
   los servos

## 3. Los cambios, uno a uno

### `generador/sensors.js` — es el que arregla los bloques

Afecta a `ultrasonic_sensor`, en sus **dos variantes** (la general y el caso
especial `TRIG=4`/`ECHO=5`), porque el generador duplica la función.

| | antes | ahora |
|---|---|---|
| Ancho del disparo (variante general) | `delayMicroseconds(10)` | **`delayMicroseconds(25)`** |
| Nivel bajo previo | `delayMicroseconds(2)` | `delayMicroseconds(4)` |
| Lectura del eco (las dos variantes) | `pulseIn(ECHO, HIGH)` | **`pulseIn(ECHO, HIGH, 25000)`** |
| Sin eco (las dos) | devolvía `0` | **`return 400`** |
| Tope de rango (las dos) | ninguno | `if (distance > 400) distance = 400;` |
| Divisor en la variante 4/5 | `/55` | **`/58`** (valor del datasheet) |

Los 25 ms de timeout cubren los 400 cm declarados: 23.2 ms de ida y vuelta.

### `libreria/Otto.h` y `Otto.cpp` — aditivos, no los usa ningún bloque todavía

Este fork **nunca** tuvo soporte de sensores: su propio README documenta un
fichero `US` que no existe. El generador sí emitía `Otto.getSensor()`, así que
ese bloque fallaba al compilar con
`error: 'class Otto' has no member named 'getSensor'`.

| método nuevo | qué hace |
|---|---|
| `getDistance()` | distancia en cm del HC-SR04, con disparo de 25 µs, timeout de 25 ms y 400 cm si no hay eco. Respeta los ~60 ms entre disparos que pide el sensor |
| `getNoise()` | media de 4 lecturas analógicas del sensor de sonido |
| `getSensor()` | **alias de `getNoise()`** — su bloque se etiqueta *"Ruido medido"*, no distancia |

**Las 37 firmas públicas anteriores siguen idénticas; solo se suman estas tres.**
Un programa existente compila y se comporta igual. Coste en un programa que no
use sensores: **+108 B de flash y +8 B de RAM**.

Macros ajustables en `Otto.h` sin tocar código: `OTTO_US_TRIGGER_PIN` (8),
`OTTO_US_ECHO_PIN` (9), `OTTO_US_DISPARO_US` (25), `OTTO_US_TIMEOUT_US` (25000),
`OTTO_US_SIN_ECO_CM` (400), `OTTO_US_INTERVALO_MS` (60), `OTTO_NOISE_PIN` (A6).

> **`OTTO_NOISE_PIN` NO está verificado.** A6 es el habitual en Otto DIY, pero en
> esta placa no hay sensor de sonido montado. Si se instala uno, comprobar el pin.

## 4. Cómo comprobar que funciona, en el PC de Windows

1. Sustituye los tres ficheros (copia de seguridad antes).
2. **Reinicia la aplicación** y recarga la página, para que el navegador no sirva
   el `sensors.js` viejo desde su caché. Si dudas, fuerza un recargado completo.
3. Monta un programa con **los dos bloques**: *"Ultrasonido Pines"* con
   **Trigger 8 / Echo 9**, y *"distancia (cm)"* dentro de un `si/entonces`.
4. **Mira el código generado** antes de subirlo: debe aparecer
   `delayMicroseconds(25)` y `pulseIn(9, HIGH, 25000)`. Si sigue poniendo 10 y un
   `pulseIn` sin tercer argumento, es la caché del navegador.
5. Sube y prueba con el robot **recién encendido**, que es el caso que fallaba.
   Apunta a una **pared**, no a una caja: el datasheet pide una superficie plana
   de al menos 0.5 m² dentro de un haz de 15°.

## 5. Lo que queda sin arreglar, y es decisión del propietario

| | |
|---|---|
| El selector **`#1..#4`** del bloque *"distancia (cm)"* se lee en `us_number` y **se descarta**: varios sensores no funcionan | es **una función que falta**, no un cálculo mal |
| El desplegable de pines ofrece **2, 3, 4, 5 y 13** —los servos y el buzzer de Otto— **sin ningún aviso** | es **una guía que falta**; tocaría la definición del bloque |
| No existe un bloque `otto_getdistance` que use `Otto.getDistance()`. El texto `"Distancia [cm]"` sí está en `Arduino_es.js`, pero el bloque no se define en `ottoesp.js` | por eso `getDistance()` viaja aquí sin que nada lo llame |

## 6. Hipótesis que quedó sin probar

**La alimentación.** El HC-SR04 está especificado para **5 V** y el riel de este
robot baja a **3.4-3.9 V** durante una marcha, porque los cuatro SG90 cuelgan del
regulador lineal del Nano. Por debajo de 4.5 V el sensor está fuera de
especificación.

No se pudo comprobar: ver la salida exige el USB, y con el USB la alimentación
entra por un Schottky y **se salta el regulador**, así que el riel nunca bajó de
4382 mV en las pruebas. **Si el sensor te falla en uso real con pilas y el robot
caminando, este es el primer sospechoso**, y para medirlo habría que volcar las
lecturas a la EEPROM y correr sin USB.

## 7. Qué se descartó, con datos

| hipótesis | cómo se descartó |
|---|---|
| Interrupciones de `Servo` falseando `pulseIn` | con los servos enganchados: **dispersión 0 cm**, idéntico a tenerlos sueltos. Y apagar las interrupciones durante el pulso no cambió nada. Coincide con el cálculo previo: 0.0 cm de error a 20 cm, 0.4 cm a 2 m |
| Pines mal elegidos en el bloque | el desplegable ya venía en 8 y 9 |
| Tiempos del TRIG/ECHO fuera de norma | verificado contra el datasheet: el disparo, la división por 58 y el ciclo de 60 ms eran correctos **según el documento**. El módulo es el que no lo cumple |
